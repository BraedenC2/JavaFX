module slide.slidingsliders {
    requires javafx.controls;
    requires javafx.fxml;


    opens slide.slidingsliders to javafx.fxml;
    exports slide.slidingsliders;
}