package bby.d8picker;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Scene1Controller {

    @FXML
    private DatePicker myDatePicker;
    @FXML
    private Label myLabel;

    public void getDate(ActionEvent event) {

        LocalDate myDate = myDatePicker.getValue();
        String myFormattedDate = myDate.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));  // This is how to format. you can use 2 m's for the numbers
        // myLabel.setText(myDate.toString()); This is how you can change the label to the date (without line 22)
        myLabel.setText(myFormattedDate);   // print format


        // THIS IS HOW YOU CAN MAKE THE CALENDAR A PASSWORD!!!
        LocalDate may22nd2003 = LocalDate.of(2003, 5, 22);
        if(myDate.equals(may22nd2003)) {
            System.out.println("The selected date is May 22nd 2003");
        }

    }

}