module bby.d8picker {
    requires javafx.controls;
    requires javafx.fxml;


    opens bby.d8picker to javafx.fxml;
    exports bby.d8picker;
}