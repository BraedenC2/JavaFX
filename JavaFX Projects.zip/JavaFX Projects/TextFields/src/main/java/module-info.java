module textfields.textfields {
    requires javafx.controls;
    requires javafx.fxml;


    opens textfields.textfields to javafx.fxml;
    exports textfields.textfields;
}