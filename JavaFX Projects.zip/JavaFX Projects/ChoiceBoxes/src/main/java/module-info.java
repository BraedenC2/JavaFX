module boxes.choiceboxes {
    requires javafx.controls;
    requires javafx.fxml;


    opens boxes.choiceboxes to javafx.fxml;
    exports boxes.choiceboxes;
}