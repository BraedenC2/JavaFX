package boxes.choiceboxes;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class Scene1Controller implements Initializable {    // We need to implement initializable, bcus choicebox doesnt have a method setter inside the stagebuilder

    @FXML
    private Label myLabel;

    @FXML
    private ChoiceBox<String> myChoiceBox;

    private String[] food = {"Pizza" , "Sushi", "Ramen"};   // Make an array String for our choices in our choice box


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {    // This will auto generate after we implement

        myChoiceBox.getItems().addAll(food);    // Add all the array elements in our choice-box
        myChoiceBox.setOnAction(this::getFood);     // this:: is a operator reference. It links the method to our choice box
    }

    public void getFood(ActionEvent event) {    // this is activated in the above method on line 27

        String myFood = myChoiceBox.getValue(); // gets the element of our choice
        myLabel.setText(myFood);        // sets the element we chose and assigns it to our label
    }

}