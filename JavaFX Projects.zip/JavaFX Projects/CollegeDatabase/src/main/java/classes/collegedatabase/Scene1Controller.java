package classes.collegedatabase;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class Scene1Controller {

    @FXML
    private TextField myTextField;

    @FXML
    private Button myButton;

    @FXML
    private Label myOutput, myOutput1, myOutput2, information;

    @FXML
    ImageView imageView;

    Image myimage = new Image("C:\\Users\\Braed\\Desktop\\JavaFX Projects\\CollegeDatabase\\src\\main\\java\\classes\\collegedatabase\\school.png");

    String input;

    public void displayImage(){
        imageView.setImage(myimage);
    }


    public void search(ActionEvent event) {


        input = myTextField.getText();
        input = input.toLowerCase();

        if (input.contains("madison")){
            information.setText("UWM or MATC?");
        }

        if (input.contains("uwm")){
            myOutput.setText("Bishop Altenburg, " +
                    "Teddy Baldukas, " +
                    "Nicholas Balthazor, " +
                    "Maxwell Beale, "+
                    "Jackson Cyvas, "+
                    "Brooks Empey, ");
            myOutput1.setText("Rachel Louis, " +
                    "Makayla McGlory, " +
                    "Nicholas Balthazor, " +
                    "Jared McGuire, "+
                    "Lizzie Moe, "+
                    "Greta Nashold, ");
            myOutput2.setText("Elise Novak, " +
                    "Alexander Orn, " +
                    "Gina Owen, " +
                    "Sol Ringen, "+
                    "Emma Solberg, "+
                    "Emma Sperle. ");
            information.setText("For more, type; \"UWM 2\"");
        }
        if (input.equals("uwm 2")){
            myOutput.setText("Jackson Talbert, " +
                    "Zayne Zeichert. ");
            myOutput1.setText(" ");
            myOutput2.setText(" ");
        }
        if (input.equals("matc")){
            myOutput.setText("Laura Camiou-Cattino, " +
                    "Gunnar Collins, " +
                    "Kyler Dobbert, " +
                    "Madison Engen, " +
                    "Max Fitzgerald, " +
                    "Samuel Flint, ");
            myOutput1.setText("Sullivan Gates," +
                    "Anna Gille," +
                    "Florijan Heta," +
                    "Conner Holvick," +
                    "Raven Jensen," +
                    "Isabella Jerrick, ");
            myOutput2.setText("Wesley Jourdan-Buskager, " +
                    "Hunter Karlen, " +
                    "JoBeth Kratz, " +
                    "Connell McGee, " +
                    "Mavery Mennes, " +
                    "Aiyanna Miller. ");
            information.setText("For more, type; \"matc 2\"");
        }
        if (input.equals("matc 2")) {
            myOutput.setText("Milot Misini-Selmani, " +
                    "Autumn Mitchell, " +
                    "Jonah O’Connor, " +
                    "Evelyn Olsen, " +
                    "Karmen Smyth, " +
                    "Hannah True, ");
            myOutput1.setText("Corvin Whitefeather, " +
                    "Brandon Wylie.");
            myOutput2.setText(" ");
        }
        if (input.contains("edgewood")) {
            myOutput.setText("Vlora Ashiku, " +
                    "Paige Bellefeuille, " +
                    "Kate Elliot, " +
                    "Jack Hoselton, " +
                    "Henry Mehring, " +
                    "Grace Ott, ");
            myOutput1.setText("Lilly Trautman. ");
            myOutput2.setText(" ");
        }
        if (input.contains("de pere") || input.contains("norbert")){
            myOutput.setText("Mara Hann – St. Norbert College.");
            myOutput1.setText(" ");
            myOutput2.setText(" ");
        }
        if (input.contains("uww") || input.contains("whitewater")){
            myOutput.setText("Lexi Abing, " +
                    "Keyontay Askew, " +
                    "Alexander Annen, " +
                    "Savannah Beckwith, " +
                    "Rudy Detweiler, " +
                    "Hailey Hedstrom. ");
            myOutput1.setText("Zaiden Lalley, " +
                    "Julia Lee, " +
                    "Benjamin Moll, " +
                    "Jasmine Molnar, " +
                    "Elita Rexhepi, " +
                    "SieSie Richardson, ");
            myOutput2.setText("Lily Weitner, " +
                    "Shelby Wise.");
        }
        if (input.contains("la crosse")) {
            myOutput.setText("Grace Gilbert, " +
                    "Jianna Krueger, " +
                    "Emma Mueller, " +
                    "Madeline Schneider, " +
                    "Connor Wheeler. ");
            myOutput1.setText(" ");
            myOutput2.setText(" ");
        }
        if (input.contains("eau claire ")) {
            myOutput.setText("Lindsey Bakken, " +
                    "Rachel Foldy, " +
                    "Aaron Mittelsteadt, " +
                    "Brett Morovic, " +
                    "McKenna Nelson, " +
                    "Reece Sproul,");
            myOutput1.setText("Ellie Trieloff. ");
            myOutput2.setText(" ");
        }
        if (input.contains("platteville")){
            myOutput.setText("UW Platteville: " +
                    "Aidan Oliver, " +
                    "Makayla Ramberg, " +
                    "Jayce Taylor. ");
            myOutput1.setText("Southwest Technical College: " +
                    "Jaden Clausen.");
            myOutput2.setText(" ");
        }
        if (input.contains("milwaukee")) {
            myOutput.setText("UW Milwaukee: " +
                    "");
            myOutput1.setText("");
            myOutput2.setText(" ");
        }

    }

}