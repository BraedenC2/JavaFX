module classes.collegedatabase {
    requires javafx.controls;
    requires javafx.fxml;


    opens classes.collegedatabase to javafx.fxml;
    exports classes.collegedatabase;
}