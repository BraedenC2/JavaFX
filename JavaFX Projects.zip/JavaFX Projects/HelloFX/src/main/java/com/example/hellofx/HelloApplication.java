package com.example.hellofx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCombination;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {


    public static void main(String[] args) {
        launch(args); // The start method will automatically be called
    }

    @Override
    public void start(Stage stage) throws Exception {
        // Stage stage1 = new Stage(); If you need to create another stage

        Group root = new Group();
        Scene scene = new Scene(root, Color.BLACK); // The scene comes before the stage. Set the scene before the stage

        Image icon = new Image("C:\\Users\\Braed\\IdeaProjects\\HelloFX\\src\\GAH.png");    // This is how you create an image variable.

        stage.getIcons().add(icon); // How you add an image to our icon window
        stage.setTitle("Stage Demo Program");   // This sets a title for the program

        stage.setWidth(420);    // This is how you set the stages width
        stage.setHeight(420);   // and height

        stage.setResizable(false);  // This is how you allow/disallow the stage to be resizable.

        stage.setX(50);     // This is how you set where the stage will open on the X
        stage.setY(50);     // and on the Y axis

        stage.setFullScreen(true); // This is how you set your stage to full screen
        stage.setFullScreenExitHint("YOU CAN'T ESCAPE unless you press q"); // This will show when the screen becomes full screen
        stage.setFullScreenExitKeyCombination(KeyCombination.valueOf("q")); // This will allow us to change what will close the full screen. By default, it is esc.


        stage.setScene(scene);
        stage.show(); // Make sure this is at the end of the stat method. Allows us to see the stage
    }
}