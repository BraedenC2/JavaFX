package com.example.hellofx;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Drawing extends Application {

    public static void main(String[] args) {
        launch(args);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {

        Group root = new Group();
        Scene scene = new Scene(root, 600, 600, Color.LIGHTSKYBLUE); // The numbers are how we can change the width and height for the Scene
        Stage stage = new Stage();

        Text text = new Text(); // This is how you create a new Text variable
        text.setText("Whoa"); // This is how you set that text to that variable
        text.setX(50);  // This is how you set the location of the text on the X
        text.setY(50);  // and on the Y axis
        text.setFont(Font.font("Verdana", 50)); // This is how you set the font of the text. 50 is the size of the font
        text.setFill(Color.LAWNGREEN);

        Line line = new Line(); // This is how you create a line
        line.setStartX(200);    // This is how you set the x
        line.setStartY(200);    // and y of the starting point
        line.setEndX(500);      // This is how you set the end point x
        line.setEndY(200);      // and y
        line.setStrokeWidth(5);     // This is how you set the Stroke Width
        line.setStroke(Color.YELLOW);   // This is how you set the color of the stroke
        line.setOpacity(0.5);   // This is how you set the opacity (0 to 1)
        line.setRotate(45);     // This is how you rotate a line

        Rectangle rectangle = new Rectangle();  // This is how you create a rectangle
        rectangle.setX(100);    // This is how you create the points of X
        rectangle.setY(100);    // and Y
        rectangle.setWidth(100);    // This is how you set the width of the rectangle
        rectangle.setHeight(100);   // and height
        rectangle.setFill(Color.BLUE);  // This is how oyu set the fill color of the rectangle
        rectangle.setStrokeWidth(5); // This is how you set the outer line of the rectangle
        rectangle.setStroke(Color.BLACK);   // This is how you change the color of the outer line

        Polygon triangle = new Polygon();   // This is how you can create a triangle
        triangle.getPoints().setAll(
                200.0, 200.0,
                300.0, 300.0,
                200.0, 300.0);      // This is how you set points with Polygons
        triangle.setFill(Color.YELLOW); // This is how you fill in the triangle with a color

        Circle circle = new Circle();   // This how you create a circle
        circle.setCenterX(350);     // This is how you create the center at a specific point x
        circle.setCenterY(350);     // and for y
        circle.setRadius(50);       // this is how you set the radius
        circle.setFill(Color.ORANGE);   // This is how you set the fill color

        Image image = new Image("C:\\Users\\Braed\\IdeaProjects\\HelloFX\\src\\Pikachu.png");
        ImageView imageView = new ImageView(image); // This is how we allow the image in our stage
        imageView.setX(300);    // set location of x and
        imageView.setY(400);     // y


        root.getChildren().add(text); // this is how you add the text to the group (which the group shows it to the scene
        root.getChildren().add(line); // this is how you add the line to the group
        root.getChildren().add(rectangle);  // This is how you add the rectangle to the group
        root.getChildren().add(triangle);   // This is how you add the polygon (triangle) to the group
        root.getChildren().add(circle);     // This is how you add a circle to the group
        root.getChildren().add(imageView);  // This is how you add an image to the group

        stage.setScene(scene);
        stage.show();


    }
}
