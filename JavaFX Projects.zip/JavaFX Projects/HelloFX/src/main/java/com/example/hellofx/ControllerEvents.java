package com.example.hellofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.shape.Circle;

public class ControllerEvents {

    @FXML   // mark a field or a method as being a part of the user interface and that it can be used in an FXML document.
    private Circle myCircle;    // To assign this to our circle in the builder, in the builder we go to fx:id and type in this name
    private double x;
    private double y;



    public void up(ActionEvent e) {     // ActionEvent e makes this method usable in the builder
        System.out.println("UP");       // This will print UP in the terminal
        myCircle.setCenterY(y-=10);     // This will move the center Y -10
    }


    public void down(ActionEvent e) {   // With the other ActionEvents, in the builder, we click the object we want, and assign it
                                // to the preferred method here with using "On Action"
        System.out.println("DOWN");
        myCircle.setCenterY(y+=10);
    }


    public void left(ActionEvent e) {
        System.out.println("LEFT");
        myCircle.setCenterX(x-=10);     // This will move the center X -10
    }


    public void right(ActionEvent e) {
        System.out.println("RIGHT");
        myCircle.setCenterX(x+=10);
    }



}
