module logout.logout {
    requires javafx.controls;
    requires javafx.fxml;


    opens logout.logout to javafx.fxml;
    exports logout.logout;
}