package viewing.imageviewing;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Scene1Controller {

    // ImageView is a Node used for painting images loaded with Images
    // Image = photograph
    // ImageView = picture frame

    @FXML

    ImageView myImageView;
    ImageView newImageView;
    @FXML
    Button myButton;

    Image myImage = new Image("C:\\Users\\Braed\\Desktop\\JavaFX Projects\\Imageviewing\\src\\shrek1.png");
    Image newImage = new Image("C:\\Users\\Braed\\Desktop\\JavaFX Projects\\Imageviewing\\src\\shrek2.jpg");


    public void displayImage(){
        myImageView.setImage(myImage);
    }

    public void myButton(ActionEvent event) {
        myImageView.setImage(newImage);
    }




}