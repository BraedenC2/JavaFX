module viewing.imageviewing {
    requires javafx.controls;
    requires javafx.fxml;


    opens viewing.imageviewing to javafx.fxml;
    exports viewing.imageviewing;
}