module checkboxes.checkboxes {
    requires javafx.controls;
    requires javafx.fxml;


    opens checkboxes.checkboxes to javafx.fxml;
    exports checkboxes.checkboxes;
}