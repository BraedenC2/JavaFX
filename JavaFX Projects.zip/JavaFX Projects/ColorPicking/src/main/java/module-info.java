module colors.colorpicking {
    requires javafx.controls;
    requires javafx.fxml;


    opens colors.colorpicking to javafx.fxml;
    exports colors.colorpicking;
}