module communication.communication {
    requires javafx.controls;
    requires javafx.fxml;


    opens communication.communication to javafx.fxml;
    exports communication.communication;
}