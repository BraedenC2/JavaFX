module load.loadingloader {
    requires javafx.controls;
    requires javafx.fxml;


    opens load.loadingloader to javafx.fxml;
    exports load.loadingloader;
}