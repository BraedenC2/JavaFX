module myheart.radio {
    requires javafx.controls;
    requires javafx.fxml;


    opens myheart.radio to javafx.fxml;
    exports myheart.radio;
}