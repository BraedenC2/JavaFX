module switching.switching {
    requires javafx.controls;
    requires javafx.fxml;


    opens switching.switching to javafx.fxml;
    exports switching.switching;
}